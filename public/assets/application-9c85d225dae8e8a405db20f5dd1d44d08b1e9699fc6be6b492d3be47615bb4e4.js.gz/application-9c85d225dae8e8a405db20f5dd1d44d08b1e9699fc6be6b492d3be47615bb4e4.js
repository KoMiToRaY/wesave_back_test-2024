import "chartkick"
import "Chart.bundle"

import "../stylesheets/application.css";
