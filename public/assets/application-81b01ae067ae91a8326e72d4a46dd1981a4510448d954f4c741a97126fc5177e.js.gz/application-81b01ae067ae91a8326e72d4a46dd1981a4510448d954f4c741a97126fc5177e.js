import "chartkick"
import "Chart.bundle"

// import "../stylesheets/tailwind/application.css";
