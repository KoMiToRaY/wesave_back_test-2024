import "chartkick"
import "Chart.bundle"

import "../stylesheets/application.css"
import "../stylesheets/application.tailwind.css";
